from pathlib import Path
from fastapi import FastAPI, Body, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import uvicorn
import asyncio
import sqlite3
from docx import Document
from fastapi.responses import StreamingResponse
from io import BytesIO
import secrets
from fastapi import Header
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Mm

app = FastAPI()
ACTIVE_TOKENS = {}

# Отдаём index.html по корню
@app.get("/")
def index():
    return FileResponse("index.html")

@app.get("/table")
def table_page():
    return FileResponse("table.html")

# Раздаём папки css и js как статику
app.mount("/css", StaticFiles(directory="css"), name="css")
app.mount("/js", StaticFiles(directory="js"), name="js")

def connect_db():
    conn = sqlite3.connect('db')
    # PRAGMA foreign_keys НЕ включаем — мешает renumber_main
    return conn


def read_db(c):
    # функция чтения данных
    request = f"""
				SELECT * 
				FROM main m
				LEFT JOIN applicant a ON m.id = a.id_main;
			  """
    c.execute(request)
    rows = c.fetchall()

    return rows


def add(c, data):
    # функция добавления данных
    for line in data:
        request = """INSERT INTO main (
			date, decision, responsible, commentary, deadline, performed, comment_execution)
			VALUES (?, ?, ?, ?, ?, ?, ?)
			RETURNING id"""

        rows = []
        number = None
        for i in range(len(line)):
            if isinstance(line[i], list):
                number = i
            else:
                rows.append(line[i])

        c.execute(request, tuple(rows))
        id_main = c.fetchone()[0]

        for elem in line[number]:
            request = """INSERT INTO applicant (id_main, applicant) VALUES (?, ?)"""
            c.execute(request, (id_main, elem))


def delete(c, data):
    # функция удаления данных
    for elem in data:
        c.execute("DELETE FROM main WHERE id = ?", (elem,))
def renumber_main(c):
    rows = c.execute("SELECT id FROM main ORDER BY id").fetchall()
    old_ids = [r[0] for r in rows]
    if not old_ids:
        return

    mapping = {old: new for new, old in enumerate(old_ids, start=1)}

    if all(old == new for old, new in mapping.items()):
        return

    # applicant: old -> -new
    for old, new in mapping.items():
        if old != new:
            c.execute("UPDATE applicant SET id_main = ? WHERE id_main = ?", (-new, old))
    # applicant: -new -> new
    for old, new in mapping.items():
        if old != new:
            c.execute("UPDATE applicant SET id_main = ? WHERE id_main = ?", (new, -new))

    # main: old -> -new
    for old, new in mapping.items():
        if old != new:
            c.execute("UPDATE main SET id = ? WHERE id = ?", (-new, old))
    # main: -new -> new      ← ЗДЕСЬ -new, а не -old
    for old, new in mapping.items():
        if old != new:
            c.execute("UPDATE main SET id = ? WHERE id = ?", (new, -new))
def require_admin(authorization: str):
    if not authorization:
        raise HTTPException(status_code=401, detail="Требуется вход")
    parts = authorization.split()
    token = parts[-1] if parts else ""
    info = ACTIVE_TOKENS.get(token)
    if not info:
        raise HTTPException(status_code=401, detail="Токен недействителен")
    if info["role"] != "admin":
        raise HTTPException(status_code=403, detail="Недостаточно прав")
    return info

@app.get("/read_table")
def read_table():
    """читаем данные"""
    conn = connect_db()
    c = conn.cursor()
    try:
        rows = read_db(c)
        return {"status": "ok", "data": rows}
    except Exception as e:
        HTTPException(status_code=500, detail=f"❌ Ошибка чтения данных")


@app.post("/add_table")
def add_table(data: list = Body(...)):
    """добавляем данные"""
    conn = connect_db()
    c = conn.cursor()
    try:
        add(c, data)
        conn.commit()
        return {"status": "ok", "message": "✅ Данные успешно добавлены!"}
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"❌ Ошибка добавления данных: {e}")

@app.post("/change_table")
def change_table(data: list = Body(...)):
    """изменяем данные"""
    conn = connect_db()
    c = conn.cursor()
    try:
        del_data = [line[0] for line in data]
        delete(c, del_data)

        add_data = [
            [line[elem] for elem in range(len(line)) if elem != 0] for line in data
        ]
        add(c, add_data)
        conn.commit()
        return {"status": "ok", "message": "✅ Данные успешно изменены!"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"❌ Ошибка изменения данных")


@app.post("/delete_table")
def delete_table(data: list = Body(...)):
    """удаляем данные"""
    conn = connect_db()
    c = conn.cursor()
    try:
        delete(c, data)
        conn.commit()
        return {"status": "ok", "message": "✅ Данные успешно удалены!"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"❌ Ошибка удаления данных")

@app.post("/update_execution")
def update_execution(data: dict = Body(...)):
    """Обновляет только performed и comment_execution по id."""
    conn = connect_db()
    c = conn.cursor()
    try:
        c.execute(
            """UPDATE main
               SET performed = ?, comment_execution = ?
               WHERE id = ?""",
            (data.get("performed", ""),
             data.get("comment_execution", ""),
             data.get("id"))
        )
        conn.commit()
        if c.rowcount == 0:
            raise HTTPException(status_code=404, detail="Запись с таким id не найдена")
        return {"status": "ok", "message": "✅ Изменения сохранены"}
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"❌ Ошибка обновления: {e}")

@app.get("/read_passwords")
def read_passwords():
    """читаем пароли"""
    conn = connect_db()
    c = conn.cursor()
    try:
        request = '''SELECT * FROM passwords'''
        c.execute(request)
        rows = c.fetchall()
        return {"status": "ok", "data": rows}
    except Exception as e:
        HTTPException(status_code=500, detail=f"❌ Ошибка чтения паролей")


@app.post("/add_passwords")
def add_passwords(data: list = Body(...)):
    """добавление пароля"""
    conn = connect_db()
    c = conn.cursor()
    try:
        for elem in data:
            request = """INSERT INTO passwords (login, password, role)
						VALUES (?, ?, ?)"""
            c.execute(request, tuple(elem))
        conn.commit()
        return {"status": "ok", "message": "✅ Пароль успешно добавлен!"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"❌ Ошибка добавления пароля")


@app.post("/delete_passwords")
def delete_passwords(data: list = Body(...)):
    """удаление пароля"""
    conn = connect_db()
    c = conn.cursor()
    try:
        for elem in data:
            c.execute("DELETE FROM passwords WHERE id = ?", (elem,))
        conn.commit()
        return {"status": "ok", "message": "✅ Пароль успешно удален!"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"❌ Ошибка удаления пароля")


@app.post("/change_passwords")
def change_passwords(data: list = Body(...)):
    """изменение пароля"""
    conn = connect_db()
    c = conn.cursor()
    try:
        del_data = [line[0] for line in data]
        for elem in del_data:
            c.execute("DELETE FROM passwords WHERE id = ?", (elem,))

        add_data = [
            [line[elem] for elem in range(len(line)) if elem != 0] for line in data
        ]
        for elem in add_data:
            request = """INSERT INTO passwords (login, password, role)
						VALUES (?, ?, ?)"""
            c.execute(request, tuple(elem))
        conn.commit()
        return {"status": "ok", "message": "✅ Пароль успешно изменен!"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"❌ Ошибка изменения пароля")

@app.post("/login")
def login(data: dict = Body(...)):
    """Проверяет логин/пароль, возвращает токен."""
    conn = connect_db()
    c = conn.cursor()
    try:
        c.execute("SELECT id, role FROM passwords WHERE login=? AND password=?",
                  (data.get("login"), data.get("password")))
        row = c.fetchone()
        if not row:
            raise HTTPException(status_code=401, detail="Неверный логин или пароль")

        # Генерируем токен
        token = secrets.token_urlsafe(32)
        ACTIVE_TOKENS[token] = {
            "login": data.get("login"),
            "role": row[1],
        }
        return {"status": "ok", "token": token, "role": row[1]}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка входа: {e}")

@app.get("/me")
def me(authorization: str = Header(None)):
    """Проверяет токен и возвращает роль."""
    if not authorization:
        return {"status": "anonymous"}
    # Ждём формат "Bearer <token>"
    parts = authorization.split()
    token = parts[-1] if parts else ""
    info = ACTIVE_TOKENS.get(token)
    if not info:
        return {"status": "anonymous"}
    return {"status": "ok", "login": info["login"], "role": info["role"]}

@app.post("/add_row")
def add_row(data: dict = Body(...), authorization: str = Header(None)):
    """Добавляет одну строку в main (+соисполнители)."""
    require_admin(authorization)
    conn = connect_db()
    c = conn.cursor()
    try:
        c.execute(
            """INSERT INTO main
               (date, decision, responsible, commentary, deadline, performed, comment_execution)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               RETURNING id""",
            (data.get("date", ""),
             data.get("decision", ""),
             data.get("responsible", ""),
             data.get("commentary", ""),
             data.get("deadline", ""),
             data.get("performed", ""),
             data.get("comment_execution", ""))
        )
        id_main = c.fetchone()[0]

        for elem in data.get("applicants", []):
            if elem.strip():
                c.execute("INSERT INTO applicant (id_main, applicant) VALUES (?, ?)",
                          (id_main, elem))

        conn.commit()
        return {"status": "ok", "id": id_main, "message": "✅ Строка добавлена"}
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Ошибка добавления: {e}")


@app.post("/delete_row")
def delete_row(data: dict = Body(...), authorization: str = Header(None)):
    require_admin(authorization)
    conn = connect_db()
    c = conn.cursor()
    try:
        row_id = data.get("id")
        if row_id is None:
            raise HTTPException(status_code=400, detail="Не указан id")

        c.execute("BEGIN")                # ← явная транзакция
        c.execute("DELETE FROM applicant WHERE id_main=?", (row_id,))
        c.execute("DELETE FROM main WHERE id=?", (row_id,))
        renumber_main(c)
        conn.commit()
        return {"status": "ok", "message": "✅ Строка удалена"}
    except HTTPException:
        conn.rollback()                   # ← откат при ошибке
        raise
    except Exception as e:
        conn.rollback()
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Ошибка удаления: {e}")

@app.post("/download_protocol")
def download_protocol(data: dict = Body(...)):
    import traceback
    try:
        doc = Document()

        # Настройка отступов страницы
        section = doc.sections[0]
        section.left_margin = Mm(30)   # Стандартный левый отступ (3 см)
        section.right_margin = Mm(16.5) # Ваш правый отступ (1.65 см)
        section.top_margin = Mm(20)    # Верхний отступ (2 см)
        section.bottom_margin = Mm(20) # Нижний отступ (2 см)
        # Задаём стиль Normal: Times New Roman 12
        style = doc.styles['Normal']
        style.font.name = 'Times New Roman'
        style.font.size = Pt(12)
        # Для правильного отображения кириллицы в Word задаём и восточноевропейский шрифт
        style.element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
        style.element.rPr.rFonts.set(qn('w:cs'), 'Times New Roman')
        # Заголовок
        h = doc.add_paragraph()
        h.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = h.add_run("ПРОТОКОЛ")
        run.bold = True
        run.font.size = Pt(16)
        run.font.name = 'Times New Roman'

        sub = doc.add_paragraph()
        sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
        sub.add_run('заседания Административного совета АНПОО «Образовательный центр "Участие"»')

        # Дата и время
        p_date = doc.add_paragraph()
        r_date = p_date.add_run(f"Дата: {data.get('date', '')}    Время: {data.get('time', '')}")
        r_date.bold = True

        # Присутствовали
        doc.add_paragraph("Присутствовали:")
        admins = data.get("admins", [])
        if admins:
            doc.add_paragraph("Члены АдминСовета: " + ", ".join(map(str, admins)))
        participants = data.get("participants", [])
        if participants:
            doc.add_paragraph("Приглашённые участники: " + ", ".join(map(str, participants)))

         # Повестка
        p_agenda = doc.add_paragraph()
        r_agenda = p_agenda.add_run("ПОВЕСТКА:")
        r_agenda.bold = True
        agendas = data.get("agendas", [])
        for i, a in enumerate(agendas, start=1):
            doc.add_paragraph(f"{i}. {a}")

        # Вопросы
        for i, q in enumerate(data.get("questions", []), start=1):
            doc.add_paragraph()  # пустая строка
            p = doc.add_paragraph()
            run = p.add_run(f"По вопросу №{i} «{q.get('agenda', '')}»")
            run.bold = True

                        # Слушали
            p = doc.add_paragraph()
            p.add_run("Слушали: ").bold = True
            p.add_run(q.get('listen', ''))

            # Предложения (не жирным)
            doc.add_paragraph(f"Предложения: {q.get('offer', '')}")

            # Решили
            p = doc.add_paragraph()
            p.add_run("Решили: ").bold = True
            p.add_run(q.get('solution', ''))

            # Ответственный
            doc.add_paragraph(f"Ответственный: {q.get('responsible', '')}")

            # Соисполнители
            execs = q.get("executors", [])
            if execs:
                doc.add_paragraph("Соисполнители: " + ", ".join(map(str, execs)))

            # Срок
            p = doc.add_paragraph()
            p.add_run("Срок: ").bold = True
            p.add_run(q.get('deadline', ''))

            # Комментарий
            doc.add_paragraph(f"Комментарий: {q.get('comment', '')}")
            doc.add_paragraph(
                f"Голосовали: За — {q.get('yes', '')}, "
                f"Против — {q.get('no', '')}, "
                f"Воздержались — {q.get('hz', '')}"
            )

        # Подписи
        doc.add_paragraph()
        doc.add_paragraph("Подписи:")
        doc.add_paragraph(f"Председатель: ______________________ / {data.get('chairman', '')}")
        doc.add_paragraph(f"Секретарь:    ______________________ / {data.get('secretary', '')}")

        # Сохраняем в память
        stream = BytesIO()
        doc.save(stream)
        stream.seek(0)

        filename = f"protocol_{data.get('date', 'date')}.docx"
        headers = {
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Access-Control-Expose-Headers": "Content-Disposition",
        }

        return StreamingResponse(
            stream,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers=headers,
        )
    except Exception as e:
        traceback.print_exc() # ← это выведет красную ошибку в терминал
        raise HTTPException(status_code=500, detail=str(e))

'''
@app.get("/download_table")
async def download_table():
	#экспорт данных в WORD
	conn = connect_db()
	c = conn.cursor()
	data = read_db(c)
	
	print(data)

	doc = Document()
	table = doc.add_table(rows=len(data), cols=len(data[0]))
	table.style = "Light Shading Accent 1"

	for r_idx, row in enumerate(data):
		for c_idx, val in enumerate(row):
			table.cell(r_idx, c_idx).text = str(val)

	file_stream = BytesIO()
	doc.save(file_stream)
	file_stream.seek(0)

	headers = {"Content-Disposition": "attachment; filename=только_что_скаченный файл.docx"}

	return StreamingResponse(
	  file_stream,
	  media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
	  headers=headers,
	)
'''
	

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
