let isAdmin = false;
let currentToken = null;
let currentSortField = 'date';
let currentSortOrder = 'desc';
document.addEventListener('DOMContentLoaded', init);

async function init() {
    currentToken = localStorage.getItem('token');
    const role = localStorage.getItem('role');

    if (currentToken) {
        // Проверяем токен на сервере
        try {
            const r = await fetch('/me', {
                headers: { 'Authorization': 'Bearer ' + currentToken }
            });
            const me = await r.json();
            if (me.status === 'ok' && me.role === 'admin') {
                isAdmin = true;
            }
        } catch (e) { /* ignore */ }
    }

    updateUIForRole();
    updateSortIndicators();
    loadTable();
    // Обработчик кликов
    document.querySelectorAll('th.sortable').forEach(th => {
        th.style.cursor = 'pointer';
        th.addEventListener('click', () => {
            const field = th.dataset.sort;
            
            if (currentSortField === field) {
                currentSortOrder = currentSortOrder === 'asc' ? 'desc' : 'asc';
            } else {
                currentSortField = field;
                if (field === 'date') currentSortOrder = 'desc';
                else if (field === 'deadline') currentSortOrder = 'asc';
                else if (field === 'performed') currentSortOrder = 'desc';
                else currentSortOrder = 'asc';
            }
            
            updateSortIndicators();
            loadTable();
        });
    });

    // Функция обновления стрелочек
    function updateSortIndicators() {
        document.querySelectorAll('th.sortable').forEach(th => {
            const field = th.dataset.sort;
            // Берем изначальный текст из атрибута data-text
            let text = th.dataset.text || th.textContent;

            if (field === currentSortField) {
                // Если это активная колонка, ставим нужную стрелку
                text += currentSortOrder === 'asc' ? ' ▲' : ' ▼';
            } else {
                // Иначе ставим обе стрелочки как индикатор
                text += ' ⇅';
            }
            th.textContent = text;
        });
    }
}

function updateUIForRole() {
    const adminBar = document.getElementById('adminBar');
    const adminPanel = document.getElementById('adminPanel');

    // Верхняя панель (кнопка входа/выхода)
    if (adminBar) {
        if (isAdmin) {
            adminBar.innerHTML = `<button id="logoutBtn">Выход</button>`;
            document.getElementById('logoutBtn').onclick = logout;
        } else {
            adminBar.innerHTML = `<button id="loginBtn">Войти как администратор</button>`;
            document.getElementById('loginBtn').onclick = openLoginModal;
        }
    }

    // Панель под таблицей (только для админа)
    if (adminPanel) {
        adminPanel.style.display = isAdmin ? 'block' : 'none';
        if (isAdmin) {
            document.getElementById('deleteRowBtn').onclick = deleteRowById;
        }
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    window.location.reload();
}

async function loadTable() {
    const tbody = document.querySelector('#table tbody');
    tbody.innerHTML = '';

    try {
        const response = await fetch('/read_table');
        const result = await response.json();

        if (!response.ok || result.status !== 'ok') {
            tbody.innerHTML = '<tr><td colspan="13">Ошибка загрузки</td></tr>';
            return;
        }

        const grouped = new Map();
        for (const row of result.data) {
            const id = row[0];
            const applicant = row[10];

            if (!grouped.has(id)) {
                grouped.set(id, {
                    id:          row[0],
                    date:        row[1],
                    decision:    row[2],
                    responsible: row[3],
                    commentary:  row[4],
                    deadline:    row[5],
                    performed:   row[6],
                    commentExec: row[7],
                    applicants:  []
                });
            }
            if (applicant !== null && applicant !== undefined) {
                grouped.get(id).applicants.push(applicant);
            }
        }

        // Преобразуем Map в массив для сортировки
        let items = Array.from(grouped.values());

        // Применяем сортировку
        if (currentSortField) {
            items.sort((a, b) => {
                let valA, valB;

                if (currentSortField === 'id') {
                    valA = a.id;
                    valB = b.id;
                } else if (currentSortField === 'date') {
                    valA = a.date || '';
                    valB = b.date || '';
                } else if (currentSortField === 'deadline') {
                    valA = a.deadline || '';
                    valB = b.deadline || '';
                } else if (currentSortField === 'performed') {
                    valA = normalizePerformed(a.performed);
                    valB = normalizePerformed(b.performed);
                }

                let result = 0;
                if (valA < valB) result = -1;
                if (valA > valB) result = 1;

                // Инвертируем для убывания
                return currentSortOrder === 'asc' ? result : -result;
            });
        } else {
            // Если сортировка не выбрана, по умолчанию по id (возрастание)
            items.sort((a, b) => a.id - b.id);
        }

        for (const item of items) {
            tbody.appendChild(buildRow(item));
        }

        if (grouped.size === 0) {
            tbody.innerHTML = '<tr><td colspan="13">Нет данных</td></tr>';
        }
    } catch (err) {
        console.error(err);
        tbody.innerHTML = '<tr><td colspan="13">Ошибка соединения</td></tr>';
    }
}

function buildRow(item) {
    const tr = document.createElement('tr');

    const execs = item.applicants.slice(0, 5);
    while (execs.length < 5) execs.push('-');

    // Все НЕредактируемые ячейки, кроме двух последних
    const plainCells = [
        item.id,
        item.date        || '-',
        item.decision    || '-',
        item.responsible || '-',
        execs[0], execs[1], execs[2], execs[3], execs[4],
        item.commentary  || '-',
        item.deadline    || '-'
    ];

    for (const value of plainCells) {
        const td = document.createElement('td');
        td.textContent = value;
        tr.appendChild(td);
    }

    // Ячейка "Исполнено": только "Да" / "Нет"
    // Нормализуем значение из БД
    const performedValue = normalizePerformed(item.performed);

    const tdPerformed = document.createElement('td');
    if (isAdmin) {
        const sel = document.createElement('select');
        sel.className = 'edit-cell performed-select';
        sel.dataset.field = 'performed';
        sel.dataset.id = item.id;

        const optNo  = document.createElement('option');
        optNo.value = 'Нет';
        optNo.textContent = 'Нет';

        const optYes = document.createElement('option');
        optYes.value = 'Да';
        optYes.textContent = 'Да';

        sel.appendChild(optNo);
        sel.appendChild(optYes);
        sel.value = performedValue;

        // При смене значения — сразу сохраняем (blur не всегда срабатывает на select)
        sel.addEventListener('change', onPerformedChange);

        tdPerformed.appendChild(sel);
    } else {
        tdPerformed.textContent = performedValue;
    }
    tr.appendChild(tdPerformed);

    // Ячейка "Комментарий к исполнению":
    //  - и админ, и обычный пользователь — input
    const tdComment = document.createElement('td');
    const inpComment = document.createElement('input');
    inpComment.type = 'text';
    inpComment.value = item.commentExec || '';
    inpComment.dataset.field = 'comment_execution';
    inpComment.dataset.id = item.id;
    inpComment.className = 'edit-cell';
    tdComment.appendChild(inpComment);
    tr.appendChild(tdComment);

    return tr;
}

async function deleteRowById() {
    const input = document.getElementById('deleteIdInput');
    const id = parseInt(input.value, 10);

    if (!id || id < 1) {
        alert('Введите корректный id строки');
        return;
    }

    if (!confirm(`Удалить строку #${id}?`)) return;

    try {
        const r = await fetch('/delete_row', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + currentToken
            },
            body: JSON.stringify({ id })
        });
        const data = await r.json();

        if (r.ok) {
            input.value = '';
            loadTable();
        } else {
            alert('Ошибка: ' + (data.detail || r.status));
        }
    } catch (e) {
        alert('Не удалось удалить: ' + e.message);
    }
}

async function addNewRow() {
    // Создаём пустую строку в БД и перезагружаем
    try {
        const r = await fetch('/add_row', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + currentToken
            },
            body: JSON.stringify({
                date: '', decision: '', responsible: '', commentary: '',
                deadline: '', performed: '', comment_execution: '',
                applicants: []
            })
        });
        const data = await r.json();
        if (r.ok) {
            loadTable();
        } else {
            alert('Ошибка: ' + (data.detail || r.status));
        }
    } catch (e) {
        alert('Не удалось добавить: ' + e.message);
    }
}

document.addEventListener('blur', async function(e) {
    if (!e.target.classList || !e.target.classList.contains('edit-cell')) return;
    // select у нас обрабатывается отдельным change-обработчиком
    if (e.target.tagName === 'SELECT') return;

    const inp = e.target;
    const id = inp.dataset.id;
    const tr = inp.closest('tr');
    if (!tr) return;

    // Значение "Исполнено" — из select, если он есть, иначе из текста ячейки
    let performedValue = 'Нет';
    const sel = tr.querySelector('select[data-field="performed"]');
    if (sel) {
        performedValue = sel.value;
    } else {
        const td = tr.children[11];
        const t = td ? td.textContent.trim() : '';
        performedValue = (t === '' || t === '-') ? 'Нет' : t;
    }

    const commentInp = tr.querySelector('.edit-cell[data-field="comment_execution"]');
    const commentValue = commentInp ? commentInp.value : '';

    const payload = {
        id: parseInt(id, 10),
        performed: performedValue,
        comment_execution: commentValue
    };

    try {
        const r = await fetch('/update_execution', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await r.json();

        if (r.ok) {
            inp.style.background = '#d4edda';
            setTimeout(() => { inp.style.background = ''; }, 500);
        } else {
            alert('Ошибка: ' + (data.detail || r.status));
        }
    } catch (err) {
        console.error(err);
        alert('Не удалось сохранить: ' + err.message);
    }
}, true);

document.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.classList?.contains('edit-cell')) {
        e.target.blur();
    }
});

function openLoginModal() {
    const modal = document.getElementById('loginModal');
    const form = document.getElementById('modalLoginForm');
    const errP = document.getElementById('modalLoginError');

    form.reset();
    errP.textContent = '';
    modal.style.display = 'flex';

    // Фокус на первое поле
    setTimeout(() => {
        document.getElementById('modalLoginInput').focus();
    }, 50);
}

function closeLoginModal() {
    document.getElementById('loginModal').style.display = 'none';
}

// Обработчик формы внутри модалки
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('modalLoginForm');
    const cancelBtn = document.getElementById('modalCancelBtn');
    const overlay = document.getElementById('loginModal');

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const login = document.getElementById('modalLoginInput').value;
            const password = document.getElementById('modalPasswordInput').value;
            const errP = document.getElementById('modalLoginError');
            errP.textContent = '';

            try {
                const r = await fetch('/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ login, password })
                });
                const data = await r.json();
                if (!r.ok) {
                    errP.textContent = data.detail || 'Ошибка входа';
                    return;
                }
                localStorage.setItem('token', data.token);
                localStorage.setItem('role', data.role);

                currentToken = data.token;
                isAdmin = (data.role === 'admin');

                closeLoginModal();
                updateUIForRole();
                loadTable();
            } catch (err) {
                errP.textContent = 'Ошибка соединения: ' + err.message;
            }
        });
    }

    if (cancelBtn) {
        cancelBtn.addEventListener('click', closeLoginModal);
    }

    // Клик по затемнённому фону — закрыть
    // if (overlay) {
    //     overlay.addEventListener('click', (e) => {
    //         if (e.target === overlay) closeLoginModal();
    //     });
    // }

    // Escape — закрыть
    // document.addEventListener('keydown', (e) => {
    //     if (e.key === 'Escape') closeLoginModal();
    // });
});
// Приводит любое значение из БД к "Да" или "Нет"
function normalizePerformed(value) {
    if (!value) return 'Нет';
    const v = String(value).trim().toLowerCase();
    if (v === 'да' || v === 'yes' || v === 'true' || v === '1' || v === 'выполнено') {
        return 'Да';
    }
    return 'Нет';
}

// Сохранение при смене значения в select
async function onPerformedChange(e) {
    const sel = e.target;
    const id = sel.dataset.id;
    const tr = sel.closest('tr');
    if (!tr) return;

    const commentInp = tr.querySelector('.edit-cell[data-field="comment_execution"]');
    const commentValue = commentInp ? commentInp.value : '';

    const payload = {
        id: parseInt(id, 10),
        performed: sel.value,
        comment_execution: commentValue
    };

    try {
        const r = await fetch('/update_execution', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await r.json();

        if (r.ok) {
            sel.style.background = '#d4edda';
            setTimeout(() => { sel.style.background = ''; }, 500);
        } else {
            alert('Ошибка: ' + (data.detail || r.status));
        }
    } catch (err) {
        console.error(err);
        alert('Не удалось сохранить: ' + err.message);
    }
}