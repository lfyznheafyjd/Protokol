// PlusQuestion
let plusClick = 0;
const agendaId = ["agenda2", "agenda3", "agenda4", "agenda5", "agenda6", "agenda7", "agenda8", "agenda9", "agenda10"];
const agendaIdText = ["agenda1", "agenda2", "agenda3", "agenda4", "agenda5", "agenda6", "agenda7", "agenda8", "agenda9", "agenda10"]
const questionId = [
	["question2", "question3", "question4", "question5", "question6", "question7", "question8", "question9", "question10",],
	["byQuestion2", "byQuestion3", "byQuestion4", "byQuestion5", "byQuestion6", "byQuestion7", "byQuestion8", "byQuestion9", "byQuestion10",],
	["listen2", "listen3", "listen4", "listen5", "listen6", "listen7", "listen8", "listen9", "listen10",],
	["offer2", "offer3", "offer4", "offer5", "offer6", "offer7", "offer8", "offer9", "offer10",],
	["solution2", "solution3", "solution4", "solution5", "solution6", "solution7", "solution8", "solution9", "solution10",],
	["responsible2", "responsible3", "responsible4", "responsible5", "responsible6", "responsible7", "responsible8", "responsible9", "responsible10",],
	["executor2", "executor3", "executor4", "executor5", "executor6", "executor7", "executor8", "executor9", "executor10",],
	["deadline2", "deadline3", "deadline4", "deadline5", "deadline6", "deadline7", "deadline8", "deadline9", "deadline10",],
	["comment2", "comment3", "comment4", "comment5", "comment6", "comment7", "comment8", "comment9", "comment10",],
	["yes2", "yes3", "yes4", "yes5", "yes6", "yes7", "yes8", "yes9", "yes10",],
	["no2", "no3", "no4", "no5", "no6", "no7", "no8", "no9", "no10",],
	["hz2", "hz3", "hz4", "hz5", "hz6", "hz7", "hz8", "hz9", "hz10",],
]
const byQuestionH4 = ["По вопросу №2", "По вопросу №3", "По вопросу №4", "По вопросу №5", "По вопросу №6", "По вопросу №7", "По вопросу №8", "По вопросу №9", "По вопросу №10"];
const byQuestionH4Text = ["По вопросу №1", "По вопросу №2", "По вопросу №3", "По вопросу №4", "По вопросу №5", "По вопросу №6", "По вопросу №7", "По вопросу №8", "По вопросу №9", "По вопросу №10"];
const labelText = ["Слушали:", "Предложения:", "Решили:", "Ответственный:", "Соисполнители:", "Срок:", "Комментарий:", "За", "Против", "Воздержались",];
const questionClass = ["listenI", "offerI", "solutionI", "responsibleI", "executorI", "deadlineI", "commentI", "yesI", "noI", "hzI",];
const labelClass = ["yesL", "noL", "hzL"];
const questionH4Text = ["byQuestion1", "byQuestion2", "byQuestion3", "byQuestion4", "byQuestion5", "byQuestion6", "byQuestion7", "byQuestion8", "byQuestion9", "byQuestion10",];

// PlusAdmin
let plusAdminClick = 0;
const adminId = ["admin2", "admin3", "admin4", "admin5", "admin6", "admin7", "admin8"];
const adminText = ["Эпштейн М. М.", "Фрадкин Л. Н.", "Касицина Н. В.", "Берхман Ю. В.", "Нахапетова Е. В.", "Дрёмова Т. А.", "Посевкина Ю. С.", "Голева Н. Н."];


// PlusParticipant
let plusParticipantClick = 0;
const participantId = ["participant2", "participant3", "participant4", "participant5"];
const participantText = ["Участник1", "Участник2", "Участник3", "Участник4", "Участник5"];

// PlusExecutor
let plusExecutorClick = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];


function PlusQuestion() {
	if (plusClick<9) {
		// const plus = document.getElementById("plus1");
		const agendaList = document.getElementById("agendaList");
		const newPunkt = document.createElement('li');
		const newInput = document.createElement('input');
		const newBr = document.createElement('br');
		newInput.type = "text";
		newInput.id = agendaId[plusClick];
		newInput.className = "agendaI";
		newInput.name = "agendas[]";
		agendaList.append(newPunkt);
		agendaList.append(newBr);
		newPunkt.append(newInput);

		const questions = document.getElementById("questions");
		const newQuestion = document.createElement('div');
		newQuestion.id = questionId[0][plusClick];
		newQuestion.className = "question";
		questions.append(newQuestion);
		const newHr = document.createElement('hr');
		newQuestion.append(newHr);
		const newByQuestion = document.createElement('h4');
		newByQuestion.className = "byQuestion";
		newByQuestion.id = questionId[1][plusClick];
		newByQuestion.textContent = byQuestionH4[plusClick];
		newQuestion.append(newByQuestion);
		for (let i=0; i<10; i++) {
			const newLabel = document.createElement('label');
			if (i!=4) {
				newLabel.setAttribute('for', questionId[i+2][plusClick]);
			}
			else newLabel.setAttribute('for', `${questionId[i+2][plusClick]}1`);
			newLabel.textContent = labelText[i];
			if (i>=7) {
				newLabel.className = labelClass[i-7];
			}
			newQuestion.append(newLabel);
			if (i!=4) {
				const newInput = document.createElement('input');
				if (i==5) {
					newInput.type = "date";
				}
				else newInput.type = "text";			
				newInput.id = questionId[i+2][plusClick];
				newInput.classList.add("questionI");
				newInput.classList.add(questionClass[i]);
				newInput.name = questionId[i+2][plusClick];
				newQuestion.append(newInput);
				const currentMargin = window.getComputedStyle(newInput)['margin-left'];
				newInput.style["margin-left"] = (parseFloat(currentMargin) + 4) + 'px';
				if (i!=7 && i!=8) {
					const newBr1 = document.createElement('br');
					newQuestion.append(newBr1);
					const newBr2 = document.createElement('br');
					newQuestion.append(newBr2);
				}
				if (i==6) {
					const newLabelGolos = document.createElement('label');
					newLabelGolos.textContent = "Голосовали:";
					newQuestion.append(newLabelGolos);
				}
			}
			else {
				const newOl = document.createElement('ol');
				newOl.className = 'executorList';
				newOl.id = `executorList${plusClick+2}`;
				newQuestion.append(newOl);
				const newLi = document.createElement('li');
				const newBr1 = document.createElement('br');
				const newBr2 = document.createElement('br');
				newOl.append(newLi);
				newOl.append(newBr1);
				// newOl.append(newBr2);
				const newInput = document.createElement('input');
				newInput.type = "text";
				newInput.classList.add("questionI");
				newInput.classList.add(questionClass[i]);
				newInput.id = `executor${plusClick+2}1`;
				newInput.name = `executor${plusClick+2}[]`;
				newLi.append(newInput);
				const newBtn = document.createElement('input');
				newBtn.type = "button";
				newBtn.id = `plusExecutor${plusClick+2}`;
				newBtn.className = "executorBtn";
				newBtn.value = "Добавить ещё";
				newBtn.addEventListener('click', () => {
					if (newBtn.id.slice(-1) !=0) {PlusExecutor(newBtn.id.slice(-1));}
					else PlusExecutor(10);
				});
				newQuestion.append(newBtn);
				const newBr3 = document.createElement('br');
				const newBr4 = document.createElement('br');
				newQuestion.append(newBr3);
				newQuestion.append(newBr4);
				// const currentMargin = window.getComputedStyle(newInput)['margin-left'];
				// newInput.style["margin-left"] = (parseFloat(currentMargin) + 55) + 'px';
			}
		}
		plusClick++;
	}
}
function PlusAdmin() {
	if (plusAdminClick<7) {
		const newSelect = document.createElement('select');
		const admins = document.getElementById("admins");
		newSelect.id = adminId[plusAdminClick];
		newSelect.className = "adminS";
		newSelect.name = "admins[]";
		admins.append(newSelect);
		for (let i=0; i<8; i++) {
			const newOption = document.createElement('option');
			newOption.value = i+1;
			newOption.textContent = adminText[i];
			newSelect.append(newOption);
		}
		const newBr1 = document.createElement('br');
		const newBr2 = document.createElement('br');
		admins.append(newBr1);
		admins.append(newBr2);
		plusAdminClick++;
	}
}
function PlusParticipant() {
	if (plusParticipantClick<4) {
		const newInput = document.createElement('input');
		const participants = document.getElementById("participants");
		newInput.id = participantId[plusParticipantClick];
		newInput.className = "participantI";
		newInput.name = "participants[]";
		newInput.type = "text";
		// newInput.placeholder = "ФИО участника";
		participants.append(newInput);
		const newBr1 = document.createElement('br');
		const newBr2 = document.createElement('br');
		participants.append(newBr1);
		participants.append(newBr2);
		plusParticipantClick++;
	}
}
function PlusExecutor(numberQuestion) {
	if (plusExecutorClick[numberQuestion-1]<4) {
		const executorList = document.getElementById(`executorList${numberQuestion}`);
		const newPunkt = document.createElement('li');
		const newInput = document.createElement('input');
		const newBr = document.createElement('br');
		newInput.type = "text";
		newInput.id = `executor${numberQuestion}${plusExecutorClick[numberQuestion-1]+2}`;
		newInput.name = `executor${numberQuestion}[]`;
		newInput.classList.add('questionI');
		newInput.classList.add('executorI');
		executorList.append(newPunkt);
		executorList.append(newBr);
		newPunkt.append(newInput);
		plusExecutorClick[numberQuestion-1]++;
	}
}
let timerId = setInterval(function() {
	const agendaList = document.getElementById("agendaList");
	let numberQuestion = 0;
	for (let e of agendaList.children) {
		let textByQuestion = e.children[0]?.value;
		if (e.tagName == "BR") continue
		const byQuestion = document.getElementById(questionH4Text[numberQuestion]);
		byQuestion.textContent = byQuestionH4Text[numberQuestion] + " «" + textByQuestion + "»";
		numberQuestion++;
		// console.log(textByQuestion);
	}
}, 500);
// === Отправка формы на сервер ===
document.getElementById('form').addEventListener('submit', async function(e) {
    e.preventDefault();

    // Дата заседания — общая для всех вопросов
    const date = document.getElementById('date1').value;
    const performed = "Нет";
    const commentExecution = "";

    // Определяем, сколько вопросов на странице
    const questions = document.querySelectorAll('.question');
    const result = [];

    for (let n = 1; n <= questions.length; n++) {
        // Значения полей вопроса № n
        const solution    = document.getElementById(`solution${n}`)?.value    ?? "";
        const responsible = document.getElementById(`responsible${n}`)?.value ?? "";
        const comment     = document.getElementById(`comment${n}`)?.value     ?? "";
        const deadline    = document.getElementById(`deadline${n}`)?.value    ?? "";

        // Соисполнители — это все input с name="executorN[]"
        const executors = [];
        document.querySelectorAll(`[name="executor${n}[]"]`).forEach(inp => {
            if (inp.value.trim() !== "") executors.push(inp.value);
        });

        // Строка для БД — порядок как в add():
        // [date, decision, responsible, commentary, deadline, performed, comment_execution, [applicant...]]
        result.push([
            date,
            solution,
            responsible,
            comment,
            deadline,
            performed,
            commentExecution,
            executors
        ]);
    }

    console.log('Отправляем на сервер:', result);

    try {
        const response = await fetch('/add_table', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(result)
        });

        const data = await response.json();

        if (response.ok) {
            alert(data.message || 'Данные успешно отправлены!');
        } else {
            alert('Ошибка: ' + (data.detail || response.status));
        }
    } catch (err) {
        console.error(err);
        alert('Не удалось отправить данные: ' + err.message);
    }
});
// === Скачивание протокола в DOCX ===
document.getElementById('downloadBtn').addEventListener('click', async function() {
    // Собираем данные формы (аналогично тому, как мы делаем при отправке)
    const date = document.getElementById('date1').value;
    const time = document.getElementById('time1').value;

        // Админы (у них селекты)
    const admins = [];
    document.querySelectorAll('[name="admins[]"]').forEach(el => {
        if (el.tagName === 'SELECT') {
            admins.push(el.options[el.selectedIndex]?.text ?? el.value);
        } else {
            admins.push(el.value || '');
        }
    });

    // Участники (теперь это инпуты!)
    const participants = [];
    document.querySelectorAll('[name="participants[]"]').forEach(el => {
        if (el.tagName === 'SELECT') {
            participants.push(el.options[el.selectedIndex]?.text ?? el.value);
        } else {
            participants.push(el.value || '');
        }
    });

    // Повестка
    const agendas = [];
    document.querySelectorAll('.agendaI').forEach(inp => {
        agendas.push(inp.value || '');
    });

    // Вопросы
    const questions = [];
    const questionDivs = document.querySelectorAll('.question');
    questionDivs.forEach((div, idx) => {
        const n = idx + 1;
        const get = id => document.getElementById(id)?.value ?? '';
        const executors = [];
        document.querySelectorAll(`[name="executor${n}[]"]`).forEach(inp => {
            if (inp.value.trim() !== '') executors.push(inp.value);
        });
        questions.push({
            agenda:      document.getElementById(`agenda${n}`)?.value ?? '',
            listen:      get(`listen${n}`),
            offer:       get(`offer${n}`),
            solution:    get(`solution${n}`),
            responsible: get(`responsible${n}`),
            executors:   executors,
            deadline:    get(`deadline${n}`),
            comment:     get(`comment${n}`),
            yes:         get(`yes${n}`),
            no:          get(`no${n}`),
            hz:          get(`hz${n}`)
        });
    });

    const chairmanSel = document.getElementById('chairman');
    const secretarySel = document.getElementById('secretary');
    const chairman = chairmanSel.options[chairmanSel.selectedIndex]?.text ?? '';
    const secretary = secretarySel.options[secretarySel.selectedIndex]?.text ?? '';

    const payload = {
        date, time,
        admins, participants,
        agendas,
        questions,
        chairman, secretary
    };

    try {
        const response = await fetch('/download_protocol', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
		if (!validateProtocolData(payload)) {
			return; // прерываем скачивание
		}
        if (!response.ok) {
            const err = await response.json().catch(() => ({}));
            alert('Ошибка: ' + (err.detail || response.status));
            return;
        }

        // Скачиваем файл
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');

        // Имя файла — из заголовка Content-Disposition, если есть
        let filename = `protocol_${date || 'date'}.docx`;
        const cd = response.headers.get('Content-Disposition');
        if (cd) {
            const m = cd.match(/filename="?([^"]+)"?/);
            if (m) filename = m[1];
        }

        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    } catch (err) {
        console.error(err);
        alert('Не удалось скачать: ' + err.message);
    }
});
function validateProtocolData(data) {
    const errors = [];

    // 1. Глобальные поля
    if (!data.date || !data.date.trim()) errors.push("Дата не заполнена");
    if (!data.time || !data.time.trim()) errors.push("Время не заполнено");
    
    if (!data.admins || data.admins.length === 0 || data.admins.some(a => !a || a.trim() === '')) {
        errors.push("Не указаны члены АдминСовета");
    }
    
    if (!data.participants || data.participants.length === 0 || data.participants.some(p => !p || p.trim() === '')) {
        errors.push("Не указаны приглашённые участники");
    }

    if (!data.agendas || data.agendas.length === 0 || data.agendas.some(a => !a || a.trim() === '')) {
        errors.push("Повестка не заполнена");
    }

    if (!data.chairman || !data.chairman.trim()) errors.push("Не выбран председатель");
    if (!data.secretary || !data.secretary.trim()) errors.push("Не выбран секретарь");

    // 2. Вопросы
    if (!data.questions || data.questions.length === 0) {
        errors.push("Нет ни одного вопроса");
    } else {
        data.questions.forEach((q, idx) => {
            const n = idx + 1;
            if (!q.listen || !q.listen.trim()) errors.push(`Вопрос ${n}: не заполнено "Слушали"`);
            if (!q.offer || !q.offer.trim()) errors.push(`Вопрос ${n}: не заполнено "Предложения"`);
            if (!q.solution || !q.solution.trim()) errors.push(`Вопрос ${n}: не заполнено "Решили"`);
            if (!q.responsible || !q.responsible.trim()) errors.push(`Вопрос ${n}: не заполнен "Ответственный"`);
            if (!q.deadline || !q.deadline.trim()) errors.push(`Вопрос ${n}: не заполнен "Срок"`);
            if (!q.comment || !q.comment.trim()) errors.push(`Вопрос ${n}: не заполнен "Комментарий"`);
            if (!q.yes || !q.yes.trim()) errors.push(`Вопрос ${n}: не заполнено "За"`);
            if (!q.no || !q.no.trim()) errors.push(`Вопрос ${n}: не заполнено "Против"`);
            if (!q.hz || !q.hz.trim()) errors.push(`Вопрос ${n}: не заполнено "Воздержались"`);

            if (!q.executors || q.executors.length === 0) {
                errors.push(`Вопрос ${n}: нет ни одного соисполнителя`);
            } else if (q.executors.some(e => !e || e.trim() === '')) {
                errors.push(`Вопрос ${n}: есть пустые поля соисполнителей`);
            }
        });
    }

    if (errors.length > 0) {
        alert("Пожалуйста, заполните все поля:\n\n" + errors.join("\n"));
        return false;
    }
    return true;
}